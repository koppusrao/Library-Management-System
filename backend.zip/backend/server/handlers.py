import grpc
from datetime import datetime, timedelta, date
from google.protobuf.timestamp_pb2 import Timestamp
from google.type import date_pb2

import library_pb2
import library_pb2_grpc
from db import SessionLocal, Book, Member, Loan


def to_timestamp(dt):
    if not dt:
        return None
    ts = Timestamp()
    ts.FromDatetime(dt)
    return ts


def build_loan_pb(row):
    """Build protobuf Loan object from JOIN row."""

    loan_pb = library_pb2.Loan(
        id=row.id,
        book_id=row.book_id,
        member_id=row.member_id,
        status=row.status or "",
        book_title=row.book_title or "",
        member_name=row.member_name or "",
    )

    # borrowed_at
    if row.borrowed_at:
        ts = Timestamp()
        ts.FromDatetime(row.borrowed_at)
        loan_pb.borrowed_at.CopyFrom(ts)

    # returned_at
    if row.returned_at:
        ts = Timestamp()
        ts.FromDatetime(row.returned_at)
        loan_pb.returned_at.CopyFrom(ts)

    # due_date
    if row.due_date:
        loan_pb.due_date.year = row.due_date.year
        loan_pb.due_date.month = row.due_date.month
        loan_pb.due_date.day = row.due_date.day

    return loan_pb


class LibraryService(library_pb2_grpc.LibraryServicer):

    # ---------------- Create Book ----------------
    def CreateBook(self, request, context):
        with SessionLocal() as session:
            b = request.book
            book = Book(
                title=b.title,
                author=b.author,
                isbn=b.isbn,
                published_year=b.published_year or 0,
                copies_total=b.copies_total or 1,
                copies_available=b.copies_total or 1
            )
            session.add(book)
            session.commit()
            session.refresh(book)

            return library_pb2.CreateBookResponse(
                book=library_pb2.Book(
                    id=book.id,
                    title=book.title,
                    author=book.author,
                    isbn=book.isbn,
                    published_year=book.published_year,
                    copies_total=book.copies_total,
                    copies_available=book.copies_available
                )
            )

    # ---------------- List Books ----------------
    def ListBooks(self, request, context):
        with SessionLocal() as session:
            books = session.query(Book).all()
            return library_pb2.ListBooksResponse(
                books=[
                    library_pb2.Book(
                        id=b.id,
                        title=b.title,
                        author=b.author,
                        isbn=b.isbn,
                        published_year=b.published_year,
                        copies_total=b.copies_total,
                        copies_available=b.copies_available
                    ) for b in books
                ]
            )

    # ---------------- Create Member ----------------
    def CreateMember(self, request, context):
        with SessionLocal() as session:
            m = request.member
            member = Member(
                name=m.name,
                email=m.email,
                phone=m.phone,
                address=m.address
            )
            session.add(member)
            session.commit()
            session.refresh(member)

            return library_pb2.CreateMemberResponse(
                member=library_pb2.Member(
                    id=member.id,
                    name=member.name,
                    email=member.email,
                    phone=member.phone,
                    address=member.address
                )
            )

    # ---------------- List Members ----------------
    def ListMembers(self, request, context):
        with SessionLocal() as session:
            members = session.query(Member).all()
            return library_pb2.ListMembersResponse(
                members=[
                    library_pb2.Member(
                        id=m.id,
                        name=m.name,
                        email=m.email,
                        phone=m.phone,
                        address=m.address
                    ) for m in members
                ]
            )

    # ---------------- Borrow Book ----------------
    def BorrowBook(self, request, context):
        with SessionLocal() as session:
            book = session.query(Book).filter(Book.id == request.book_id).first()
            if not book or book.copies_available <= 0:
                context.abort(grpc.StatusCode.FAILED_PRECONDITION, "Book not available")

            member = session.query(Member).filter(Member.id == request.member_id).first()
            if not member:
                context.abort(grpc.StatusCode.NOT_FOUND, "Member not found")

            now = datetime.utcnow()
            due_date = (
                date(request.due_date.year, request.due_date.month, request.due_date.day)
                if request.HasField("due_date")
                else now.date() + timedelta(days=7)
            )

            loan = Loan(
                book_id=book.id,
                member_id=member.id,
                borrowed_at=now,
                due_date=due_date,
                status="borrowed",
                created_at=now,
                updated_at=now
            )

            book.copies_available -= 1

            session.add(loan)
            session.commit()
            session.refresh(loan)

            return library_pb2.BorrowResponse(
                loan=build_loan_pb(
                    session.query(
                        Loan.id,
                        Loan.book_id,
                        Loan.member_id,
                        Loan.borrowed_at,
                        Loan.returned_at,
                        Loan.due_date,
                        Loan.status,
                        Book.title.label("book_title"),
                        Member.name.label("member_name")
                    )
                    .join(Book, Loan.book_id == Book.id)
                    .join(Member, Loan.member_id == Member.id)
                    .filter(Loan.id == loan.id)
                    .first()
                )
            )

    # ---------------- Return Book ----------------
    def ReturnBook(self, request, context):
        with SessionLocal() as session:
            loan = session.query(Loan).filter(Loan.id == request.loan_id).first()
            if not loan:
                context.abort(grpc.StatusCode.NOT_FOUND, "Loan not found")

            if loan.status != "borrowed":
                context.abort(grpc.StatusCode.FAILED_PRECONDITION, "Loan already returned")

            loan.status = "returned"
            loan.returned_at = datetime.utcnow()
            loan.updated_at = datetime.utcnow()

            book = session.query(Book).filter(Book.id == loan.book_id).first()
            if book:
                book.copies_available += 1

            session.commit()
            session.refresh(loan)

            return library_pb2.ReturnResponse(
                loan=build_loan_pb(
                    session.query(
                        Loan.id,
                        Loan.book_id,
                        Loan.member_id,
                        Loan.borrowed_at,
                        Loan.returned_at,
                        Loan.due_date,
                        Loan.status,
                        Book.title.label("book_title"),
                        Member.name.label("member_name")
                    )
                    .join(Book, Loan.book_id == Book.id)
                    .join(Member, Loan.member_id == Member.id)
                    .filter(Loan.id == loan.id)
                    .first()
                )
            )

    # ---------------- List Loans for a Member (FIXED JOIN) ----------------
    def ListLoansForMember(self, request, context):
        with SessionLocal() as session:

            rows = (
                session.query(
                    Loan.id,
                    Loan.book_id,
                    Loan.member_id,
                    Loan.borrowed_at,
                    Loan.returned_at,
                    Loan.due_date,
                    Loan.status,
                    Book.title.label("book_title"),
                    Member.name.label("member_name")
                )
                .join(Book, Loan.book_id == Book.id)
                .join(Member, Loan.member_id == Member.id)
                .filter(Member.id == request.member_id)
                .order_by(Loan.id)
                .all()
            )

            loans = [build_loan_pb(r) for r in rows]
            return library_pb2.ListLoansForMemberResponse(loans=loans)

    # ---------------- List ALL Loans ----------------
    def ListAllLoans(self, request, context):
        with SessionLocal() as session:
            loans = session.query(Loan).all()
            return library_pb2.ListAllLoansResponse(
                loans=[build_loan_pb(
                    session.query(
                        Loan.id,
                        Loan.book_id,
                        Loan.member_id,
                        Loan.borrowed_at,
                        Loan.returned_at,
                        Loan.due_date,
                        Loan.status,
                        Book.title.label("book_title"),
                        Member.name.label("member_name")
                    )
                    .join(Book, Loan.book_id == Book.id)
                    .join(Member, Loan.member_id == Member.id)
                    .filter(Loan.id == l.id)
                    .first()
                ) for l in loans]
            )