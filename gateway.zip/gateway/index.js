const express = require("express");
const cors = require("cors");
const grpc = require("@grpc/grpc-js");
const protoLoader = require("@grpc/proto-loader");
const path = require("path");

// ---------------- Load Proto ----------------
const PROTO_PATH = path.resolve(__dirname, "../backend/proto/library.proto");

const packageDefinition = protoLoader.loadSync(PROTO_PATH, {
  keepCase: true,
  longs: String,
  enums: String,
  defaults: true,
  oneofs: true,
});

const proto = grpc.loadPackageDefinition(packageDefinition).library;

// ---------------- gRPC Client ----------------
const client = new proto.Library(
  "localhost:50051",
  grpc.credentials.createInsecure()
);

const app = express();
app.use(cors());
app.use(express.json());

// ---------------- Logging ----------------
app.use((req, res, next) => {
  console.log(`>>> ${req.method} ${req.url}`);
  next();
});

// ---------------- Helper ----------------
function grpcCall(method, reqObj, res, transform = null) {
  client[method](reqObj, (err, response) => {
    if (err) {
      console.error(`❌ gRPC Error in ${method}:`, err);
      return res.status(500).send({ error: err.message, code: err.code });
    }
    if (!response) return res.send([]);

    if (transform) response = transform(response);
    res.send(response);
  });
}

// ---------------- List Books ----------------
app.get("/books", (req, res) => {
  grpcCall("ListBooks", {}, res, (r) => r.books || []);
});

// ---------------- Available Books ----------------
app.get("/available-books", (req, res) => {
  grpcCall("ListBooks", {}, res, (r) =>
    (r.books || []).filter((b) => Number(b.copies_available) > 0)
  );
});

// ---------------- List Members ----------------
app.get("/members", (req, res) => {
  grpcCall("ListMembers", {}, res, (r) => r.members || []);
});

// ========================================================
// ✅ CREATE BOOK (RESTORED)
// ========================================================
app.post("/books", (req, res) => {
  const { book } = req.body;

  if (!book) {
    return res.status(400).send({ message: "book payload missing" });
  }

  const payload = {
    book: {
      title: book.title || "",
      author: book.author || "",
      isbn: book.isbn || "",
      published_year: Number(book.published_year) || 0,
      copies_total: Number(book.copies_total) || 1,
    },
  };

  grpcCall("CreateBook", payload, res, (r) => r.book);
});

// ========================================================
// ✅ CREATE MEMBER (RESTORED)
// ========================================================
app.post("/members", (req, res) => {
  const { member } = req.body;

  if (!member) {
    return res.status(400).send({ message: "member payload missing" });
  }

  const payload = {
    member: {
      name: member.name || "",
      email: member.email || "",
      phone: member.phone || "",
      address: member.address || "",
    },
  };

  grpcCall("CreateMember", payload, res, (r) => r.member);
});

// ---------------- Borrow Book ----------------
app.post("/borrow", (req, res) => {
  const { book_id, member_id, due_date } = req.body;

  const [year, month, day] = due_date.split("-");

  grpcCall(
    "BorrowBook",
    {
      book_id: Number(book_id),
      member_id: Number(member_id),
      due_date: { year: Number(year), month: Number(month), day: Number(day) },
    },
    res,
    (r) => r.loan
  );
});

// ---------------- Return Book ----------------
app.post("/return", (req, res) => {
  const { loan_id } = req.body;

  grpcCall("ReturnBook", { loan_id: Number(loan_id) }, res, (r) => r.loan);
});

// -------------------------------------------------------
// ⭐ FIXED /loans ENDPOINT — ONLY THIS SMALL CHANGE ADDED
// -------------------------------------------------------
app.get("/loans", (req, res) => {
  const member_id = Number(req.query.member_id || 0);
  const book_id = Number(req.query.book_id || 0);
  const status = req.query.status;

  // ---------------------------------------------------
  // 1️⃣ FIXED: Filter by Member *AND* Status (borrowed)
  // ---------------------------------------------------
  if (member_id > 0) {
    grpcCall(
      "ListLoansForMember",
      { member_id },
      res,
      (r) => {
        let loans = r.loans || [];

        if (status) {
          loans = loans.filter(
            (l) =>
              String(l.status).toLowerCase() ===
              String(status).toLowerCase()
          );
        }

        return loans;
      }
    );
    return;
  }

  // ---------------------------------------------------
  // 2️⃣ All Loans or Filter by Book
  // ---------------------------------------------------
  grpcCall(
    "ListAllLoans",
    {},
    res,
    (r) => {
      let loans = r.loans || [];

      if (book_id > 0) {
        loans = loans.filter((l) => Number(l.book_id) === book_id);
      }

      return loans;
    }
  );
});

// ---------------- Start Server ----------------
app.listen(3001, () => console.log("Node Gateway running on port 3001"));