var convert = require('./convert'),
    func = convert('before', require('../before'));

func.placeholder = require('./placeholder');
module.exports = func;
